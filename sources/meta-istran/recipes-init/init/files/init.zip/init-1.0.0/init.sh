#!/bin/bash
#init script for VOX panel PC

INFLUX_ORG=ISTRAN
INFLUX_BUCKET=SaFIA
TELEGRAF_CONF_PATH=/etc/telegraf/telegraf.conf

calibrator.sh
adduser --disabled-password influxdb
addgroup influxdb
usermod -aG influxdb influxdb
systemctl enable influxdb
systemctl start influxdb
# Operator token will be generated and saved in influx connection configuration
influx setup --username istran_admin --password istran123 --org $INFLUX_ORG --bucket $INFLUX_BUCKET --force
ORG_TOKEN=$(influx auth create --all-access --host http://localhost:8086 --org $INFLUX_ORG --json | jq -r '.token')
echo "$ORG_TOKEN"
BUCKET_ID=$(influx bucket list --json | jq -r '.[] | select(.name == "SaFIA") | .id')
SAFIA_TOKEN=$(influx auth create --read-bucket "$BUCKET_ID" --write-bucket "$BUCKET_ID" --host http://localhost:8086 --org $INFLUX_ORG --json | jq -r '.token')

# add init command to rc.local
touch /usr/share/safia/init/start.sh
echo "#!/bin/bash" >> /usr/share/safia/init/start.sh
echo "export SAFIA_TOKEN=$SAFIA_TOKEN" >> /usr/share/safia/init/start.sh
echo "export ORG_TOKEN=$ORG_TOKEN" >> /usr/share/safia/init/start.sh
echo "systemctl stop weston" >> /usr/share/safia/init/start.sh
echo "cd /usr/share/safia" >> /usr/share/safia/init/start.sh
echo "dotnet SaFIAreact.Desktop.dll --drm" >> /usr/share/safia/init/start.sh
chmod +x /usr/share/safia/init/start.sh

#enable startup service
systemctl enable startup.service --now

#also save the tokens to separate file
touch /home/root/tokens.txt
echo "export SAFIA_TOKEN=$SAFIA_TOKEN" >> /home/root/tokens.txt
echo "export ORG_TOKEN=$ORG_TOKEN" >> /home/root/tokens.txt

#setup telegraf
adduser --disabled-password telegraf
addgroup telegraf
usermod -aG telegraf telegraf

# copy preinstalled config
rm /etc/telegraf/telegraf.conf
cp /usr/share/safia/init/telegraf.conf.def /etc/telegraf/telegraf.conf
mkdir -p /etc/systemd/system/telegraf.service.d
touch /etc/systemd/system/telegraf.service.d/environment.conf
echo "[Service]" >> /etc/systemd/system/telegraf.service.d/environment.conf
echo "Environment=\"SAFIA_TOKEN=$SAFIA_TOKEN\"" >> /etc/systemd/system/telegraf.service.d/environment.conf
systemctl daemon-reload
systemctl enable telegraf
systemctl restart telegraf

# copy ntp config
cp ntp.conf /etc/ntp.conf
systemctl restart ntpd

