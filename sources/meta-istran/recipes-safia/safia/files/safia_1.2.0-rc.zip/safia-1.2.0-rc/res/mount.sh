﻿#!/bin/bash

# Directory to mount the USB devices
MOUNT_DIR="/media"

# Create the mount directory if it does not exist
mkdir -p $MOUNT_DIR

# Loop through all available USB mass storage devices
for DEV in $(lsblk -rno NAME,TRAN | grep usb | awk '{print $1}'); do
  # Check each partition on the device
  for PART in $(lsblk -rno NAME /dev/$DEV | grep "^$DEV" | grep -v "^$DEV$"); do
    # Get the partition label (name)
    PART_LABEL=$(lsblk -no LABEL /dev/$PART)

    # If the partition does not have a label, use the partition name
    if [ -z "$PART_LABEL" ]; then
      PART_LABEL=$PART
    fi

    # Create the mount point directory
    MOUNT_POINT="$MOUNT_DIR/$PART_LABEL"
    mkdir -p "$MOUNT_POINT"

    # Mount the partition
    mount /dev/$PART "$MOUNT_POINT"

    # Check if the mount was successful
    if mount | grep -q "/dev/$PART"; then
      echo "Mounted /dev/$PART at $MOUNT_POINT"
    else
      echo "Failed to mount /dev/$PART"
    fi
  done
done
